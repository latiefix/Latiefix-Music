package com.latiefix.music;
import android.appwidget.*;import android.content.*;import android.widget.RemoteViews;
public class MusicWidget extends AppWidgetProvider{
 static void update(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);for(int id:m.getAppWidgetIds(new ComponentName(c,MusicWidget.class))){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_layout);v.setTextViewText(R.id.widget_title,c.getSharedPreferences("music",0).getString("current","Latiefix Music"));v.setOnClickPendingIntent(R.id.widget_play,service(c,MusicService.PLAY,10));v.setOnClickPendingIntent(R.id.widget_prev,service(c,MusicService.PREV,11));v.setOnClickPendingIntent(R.id.widget_next,service(c,MusicService.NEXT,12));m.updateAppWidget(id,v);}}
 static PendingIntent service(Context c,String a,int n){Intent i=new Intent(c,MusicService.class).setAction(a);return PendingIntent.getService(c,n,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){update(c);}
}
