# Build APK langsung dari HP

1. Buat repository GitHub baru.
2. Upload isi project ini ke repository.
3. Buka tab **Actions**.
4. Pilih **Build Latiefix Music APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai selesai.
7. Buka hasil workflow → **Artifacts** → **Latiefix-Music-APK**.
8. Download artifact dan ekstrak `app-debug.apk`.
9. Install di Android.
