# Latiefix Music 2.2

Android music player built without third-party runtime libraries.

## Features
- Folder picker + recursive audio scan
- MP3/M4A/AAC/WAV/OGG/FLAC
- Search by title/artist/album
- Metadata + embedded album art extraction
- Favorites
- Playlists + add to playlist
- Queue-style next/previous playback
- Shuffle + repeat
- Background playback with foreground notification and lock-screen MediaSession
- Play/pause/next/previous notification controls
- Seek bar + continue current playback position
- Recently/current track persistence
- Sort by title/artist/album
- Long-press song actions: playlist, share, rename, delete, info
- Sleep timer
- Built-in Android Equalizer presets when supported
- Home-screen widget
- Dark/light theme toggle
- Mini-player

## Build
Open the project in Android Studio or use Gradle 9.6 + JDK 17.
`./gradlew assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`

Note: this package intentionally does not include the Gradle wrapper JAR, so Android Studio or a local Gradle 9.6 installation is needed for the first build.
