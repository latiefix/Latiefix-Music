plugins { id("com.android.application") }

android { namespace = "com.latiefix.music"; compileSdk = 36
    defaultConfig { applicationId = "com.latiefix.music"; minSdk = 26; targetSdk = 36; versionCode = 3; versionName = "2.2.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
